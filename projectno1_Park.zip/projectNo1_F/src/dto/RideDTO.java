package dto;

public class RideDTO {
	String r_id;
	String r_name;
	String location;
	int people;
	int r_ltall;
	int r_htall;
	int ltime;
	String r_content;
	String availability;
	String img;
	
	public String getR_id() {
		return r_id;
	}
	public void setR_id(String r_id) {
		this.r_id = r_id;
	}
	public String getR_name() {
		return r_name;
	}
	public void setR_name(String r_name) {
		this.r_name = r_name;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public int getPeople() {
		return people;
	}
	public void setPeople(int people) {
		this.people = people;
	}
	public int getR_ltall() {
		return r_ltall;
	}
	public void setR_ltall(int r_ltall) {
		this.r_ltall = r_ltall;
	}
	public int getR_htall() {
		return r_htall;
	}
	public void setR_htall(int r_htall) {
		this.r_htall = r_htall;
	}
	public int getLtime() {
		return ltime;
	}
	public void setLtime(int ltime) {
		this.ltime = ltime;
	}
	public String getR_content() {
		return r_content;
	}
	public void setR_content(String r_content) {
		this.r_content = r_content;
	}
	public String getAvailability() {
		return availability;
	}
	public void setAvailability(String availability) {
		this.availability = availability;
	}
	public String getImg() {
		return img;
	}
	public void setImg(String img) {
		this.img = img;
	}
	
}

