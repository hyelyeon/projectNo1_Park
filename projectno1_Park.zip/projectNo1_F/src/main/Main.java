package main;

import swingMHW.Start;

public class Main {

	public static void main(String[] args) {
		
		Start name = new Start(50, 30, "");

	}

}
